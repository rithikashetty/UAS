package com.capgemini.appl.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity(name = "Participant")
@Table(name = "Participant")
@NamedQueries({ @NamedQuery(name = "qryAllPartcipant", query = "select p from Participant p"), })
@SequenceGenerator(name = "rollNo_generate", sequenceName = "roll_no", allocationSize = 1, initialValue = 1)
// @SequenceGenerator(name="applicationId_generate",
// sequenceName="application_id", allocationSize=1, initialValue=1)
public class Participant implements Serializable {

	private static final long serialVersionUID = 1L;
	private String rollNo;
	private String emailId;
	private int applicationId;
	private String scheduledProgramId;

	@Id
	@Column(name = "Roll_no")
	@GeneratedValue(generator = "rollNo_generate", strategy = GenerationType.SEQUENCE)
	public String getRollNo() {
		return rollNo;
	}

	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}

	@Column(name = "email_id")
	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	@Id
	@Column(name = "Application_id")
	public int getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	@Column(name = "Scheduled_program_id ")
	public String getScheduledProgramId() {
		return scheduledProgramId;
	}

	public void setScheduledProgramId(String scheduledProgramId) {
		this.scheduledProgramId = scheduledProgramId;
	}

	@Override
	public String toString() {
		return "Participant [rollNo=" + rollNo + ", emailId=" + emailId
				+ ", applicationId=" + applicationId + ", scheduledProgramId="
				+ scheduledProgramId + "]";
	}

}
